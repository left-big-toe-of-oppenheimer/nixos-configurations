-- Options are automatically loaded before lazy.nvim startup
-- Default options that are always set: https://github.com/LazyVim/LazyVim/blob/main/lua/lazyvim/config/options.lua

-- Enable wrap-around on lateral movement across lines (start/end of lines)
vim.opt.whichwrap:append("<,>,[,],h,l")
